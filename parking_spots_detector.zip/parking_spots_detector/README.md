### Parking Spots Detector

Contents:

1. Video file - parking_video.mp4

2. test_images: Two sample images to train the code on

3. train_data: Training data for CNN model

4. identify_parking_spots.ipynb - Notebook that uses OpenCV to detect each parking spot and runs the trained model to identify empty spots

5. CNN_model_for_occupany.ipynb - Notebook that uses transfer learning to train a CNN model


