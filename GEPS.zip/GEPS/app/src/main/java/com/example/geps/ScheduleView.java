package com.example.geps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import java.util.Calendar;

public class ScheduleView extends AppCompatActivity {

    Spinner mondayB;
    Spinner mondayT;

    Spinner tuesdayB;
    Spinner tuesdayT;

    Spinner wednesdayB;
    Spinner wednesdayT;

    Spinner thursdayB;
    Spinner thursdayT;

    Spinner fridayB;
    Spinner fridayT;

    Spinner saturdayB;
    Spinner saturdayT;

    Button recommendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_view);

        SharedPreferences spinnersave = getSharedPreferences("spinnerstates",0);

        mondayB = findViewById(R.id.mondayBuilding);
        mondayT = findViewById(R.id.mondayTime);

        mondayB.setSelection(spinnersave.getInt("mondayB",0));
        mondayT.setSelection(spinnersave.getInt("mondayT",1));

        tuesdayB = findViewById(R.id.tuesdayBuilding);
        tuesdayT = findViewById(R.id.tuesdayTime);

        tuesdayB.setSelection(spinnersave.getInt("tuesdayB",2));
        tuesdayT.setSelection(spinnersave.getInt("tuesdayT",3));

        wednesdayB = findViewById(R.id.wednesdayBuilding);
        wednesdayT = findViewById(R.id.wednesdayTime);

        wednesdayB.setSelection(spinnersave.getInt("wednesdayB",4));
        wednesdayT.setSelection(spinnersave.getInt("wednesdayT",5));

        thursdayB = findViewById(R.id.thursdayBuilding);
        thursdayT = findViewById(R.id.thursdayTime);

        thursdayB.setSelection(spinnersave.getInt("thursdayB",6));
        thursdayT.setSelection(spinnersave.getInt("thursdayT",7));

        fridayB = findViewById(R.id.fridayBuilding);
        fridayT = findViewById(R.id.fridayTime);

        fridayB.setSelection(spinnersave.getInt("fridayB",8));
        fridayT.setSelection(spinnersave.getInt("fridayT",9));

        saturdayB = findViewById(R.id.saturdayBuilding);
        saturdayT = findViewById(R.id.saturdayTime);

        saturdayB.setSelection(spinnersave.getInt("saturdayB",10));
        saturdayT.setSelection(spinnersave.getInt("saturdayT",11));

        recommendButton = findViewById(R.id.recommendButton);

        recommendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRecommendedParking();
            }
        });

    }

    protected void onStop(){
        super.onStop();
        SharedPreferences spinnersaving = getSharedPreferences("spinnerstates",0);

        SharedPreferences.Editor editor = spinnersaving.edit();
        editor.putInt("mondayB", mondayB.getSelectedItemPosition());
        editor.putInt("mondayT", mondayT.getSelectedItemPosition());

        editor.putInt("tuesdayB", tuesdayB.getSelectedItemPosition());
        editor.putInt("tuesdayT",tuesdayT.getSelectedItemPosition());

        editor.putInt("wednesdayB", wednesdayB.getSelectedItemPosition());
        editor.putInt("wednesdayT",wednesdayT.getSelectedItemPosition());

        editor.putInt("thursdayB", thursdayB.getSelectedItemPosition());
        editor.putInt("thursdayT",thursdayT.getSelectedItemPosition());

        editor.putInt("fridayB", fridayB.getSelectedItemPosition());
        editor.putInt("fridayT",fridayT.getSelectedItemPosition());

        editor.putInt("saturdayB", saturdayB.getSelectedItemPosition());
        editor.putInt("saturdayT",saturdayT.getSelectedItemPosition());

        editor.commit();
    }

    private void openRecommendedParking() {
        Calendar cal = Calendar.getInstance();
        int day = cal.get(Calendar.DAY_OF_WEEK);

        int destination = 0;
        switch (day) {
            case Calendar.SUNDAY:
            case Calendar.MONDAY:
                destination = mondayB.getSelectedItemPosition();
                break;
            case Calendar.TUESDAY:
                destination = tuesdayB.getSelectedItemPosition();
                break;
            case Calendar.WEDNESDAY:
                destination = wednesdayB.getSelectedItemPosition();
                break;
            case Calendar.THURSDAY:
                destination = thursdayB.getSelectedItemPosition();
                break;
            case Calendar.FRIDAY:
                destination = fridayB.getSelectedItemPosition();
                break;
            case Calendar.SATURDAY:
                destination = saturdayB.getSelectedItemPosition();
        }

        Intent intent = new Intent(this,MainActivity.class);
        switch(destination) {
            case 1:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 10:
                intent = new Intent(this,ParkingLot5.class);
                break;
            case 0:
            case 2:
            case 3:
            case 9:
            case 11:
            case 12:
            case 13:
            case 14:
                intent = new Intent(this,ParkingStructureB.class);
                break;

        }

        startActivity(intent);
    }
}
