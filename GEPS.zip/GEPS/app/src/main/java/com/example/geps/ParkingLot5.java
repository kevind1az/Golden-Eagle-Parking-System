package com.example.geps;

import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

public class ParkingLot5 extends AppCompatActivity {

    int[] spaces;
    int taggedID = -1;
    Boolean[] availability;

    View.OnClickListener tagListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (taggedID == -1) {
                v.setBackgroundResource(R.color.tagged);
                taggedID = v.getId();
            }
            else if (taggedID == v.getId()) {
                String name = getResources().getResourceEntryName(taggedID);
                int num = Integer.parseInt(name.substring(3));

                if (availability[num]) {
                    v.setBackgroundResource(R.color.vacant);
                }
                else v.setBackgroundResource(R.color.occupied);

                taggedID = -1;
            }
            else {
                ImageView prev = findViewById(taggedID);
                String prevName = getResources().getResourceEntryName(taggedID);
                int prevNum = Integer.parseInt(prevName.substring(3));

                if (availability[prevNum]) {
                    prev.setBackgroundResource(R.color.vacant);
                }
                else prev.setBackgroundResource(R.color.occupied);

                v.setBackgroundResource(R.color.tagged);
                taggedID = v.getId();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_lot5);

        spaces = new int[] {R.id.spc0,R.id.spc1,R.id.spc2,R.id.spc3,R.id.spc4,R.id.spc5,R.id.spc6,R.id.spc7,
                R.id.spc8,R.id.spc9,R.id.spc10,R.id.spc11,R.id.spc12,R.id.spc13,R.id.spc14,R.id.spc15,R.id.spc16,
                R.id.spc17,R.id.spc18,R.id.spc19,R.id.spc20,R.id.spc21,R.id.spc22,R.id.spc23,R.id.spc24,R.id.spc25,
                R.id.spc26,R.id.spc27,R.id.spc28,R.id.spc29,R.id.spc30,R.id.spc31,R.id.spc32,R.id.spc33,R.id.spc34,
                R.id.spc35,R.id.spc36,R.id.spc37,R.id.spc38,R.id.spc39};
        interpretArray();

        ImageView space = null;
        for (int id:spaces) {
            space = findViewById(id);
            space.setOnClickListener(tagListener);
        }

        SharedPreferences taggedSave = getSharedPreferences("taggedSaveID",0);
        ImageView tagged = findViewById(taggedSave.getInt("taggedID",0));

        if (tagged != null) {
            tagged.setBackgroundResource(R.color.tagged);
            taggedID = tagged.getId();
        }

    }

    private void interpretArray() {
        availability = new Boolean[40];
        BufferedReader reader;

        try{
            final InputStream file = getAssets().open("parkinglot5.txt");
            reader = new BufferedReader(new InputStreamReader(file));
            String line = "";

            int cnt = 0;
            while(line != null && cnt != 40){
                Log.d("TXT file debug", line);
                line = reader.readLine();

                availability[cnt] = Boolean.parseBoolean(line);
                ++cnt;
            }
        } catch(IOException e){
            e.printStackTrace();
        }

        ImageView space = null;
        for (int i = 0; i < spaces.length; ++i) {
            space = findViewById(spaces[i]);

            if (!availability[i]) {
                space.setBackgroundResource(R.color.occupied);
            }
            else space.setBackgroundResource(R.color.vacant);
        }

    }

    protected void onStop() {
        super.onStop();
        SharedPreferences taggedSaving = getSharedPreferences("taggedSaveID",0);
        SharedPreferences.Editor editor = taggedSaving.edit();

        editor.putInt("taggedID",taggedID);

        editor.commit();
    }

}
